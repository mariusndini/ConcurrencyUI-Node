# ConcurrencyUI-Node
Desktop Application for Concurrency testing in Snowflake. Provides ability to login, specify number of quiries to run and input specific quiries

![Screenshot](https://raw.githubusercontent.com/mariusndini/ConcurrencyUI-Node/master/screenshot.png)

